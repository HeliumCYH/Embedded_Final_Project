#include "stm32f10x.h"                 // Device header
#include "Delay.h"
#include "PP.h"
#include "Input.h"
#include "OLED.h"
#include "CountSensor.h"
#include "Encoder.h"
#include "Timer.h"
#include "Under.h"
//
#include "LCD1602v1.h"
#include "Buzzer.h"
#include "Matrix_Button.h"
#include "DS1302.h"
#include "dht11.h"

//�������ֱ�־λ
uint8_t Num_Status[10] = {0};

//
struct TIMEData TimeData;
struct TIMEData TimeRead;

//��ʱ����
extern uint8_t counter_set_timer;
uint16_t Num = 0;
uint16_t counter_ms, counter_second, counter_minute;

//����ʱ��
extern uint8_t counter_set_under;
uint16_t Under = 0;

//DHT11
extern uint8_t Data[5];

//DS1302
extern uint8_t counter_set_date;
extern uint8_t counter_set_time;

//
uint16_t Temp = 0;

int main()
{
	OLED_Init();
	Timer_Init();
	LCD_Init();
	Buzzer_Init();
	
	Matrix_Button_Init();
	
	TimeData.day = 5;
	TimeData.hour = 17;
	TimeData.minute = 28;
	TimeData.month = 9;
	TimeData.second = 17;
	TimeData.week = 4;
	TimeData.year = 2024;
	
	ds1302_data_init_time();
	
	/*
	while(1)
	{
		ds1302_data_init_time();
		ds1302_read_realTime();
		//��������ʾ
		LCD_ShowNum(0, 0, TimeData.year, 4);
		LCD_ShowChar(0, 4, '/');
		LCD_ShowNum(0, 5, TimeData.month, 2);
		LCD_ShowChar(0, 7, '/');
		LCD_ShowNum(0, 8, TimeData.day, 2);
	}
	*/
	
	//play_music();
	
	//Test
	//static int test1, test2;
	
	
	while(1)
	{
		//Test
		/*
		test1 = EXTI_GetITStatus(EXTI_Line4);
		if (test1)
		{
			LCD_ShowChar(0, 0, 'C');
		}
		test2 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4);
		if (test2)
		{
			LCD_ShowChar(0, 0, 'C');
		}
		*/
		
		//��ʱ����ʾ
		if (counter_set_timer != 0)
		{
			if (counter_set_timer == 1)
			{
				LCD1602_ClearScreen();
			}
			counter_ms = Num % 1000;
			counter_second = (Num / 1000) % 60;
			counter_minute = Num / 1000 / 60;
			
			LCD_ShowNum(1, 0, counter_minute, 1);
			LCD_ShowNum(1, 1, counter_second, 2);
			LCD_ShowNum(1, 3, counter_ms, 3);
		}
		
		
		
		//����ʱ��ʾ
		if (counter_set_under != 0)
		{
			if (counter_set_under == 1)
			{
				LCD1602_ClearScreen();
			}
			LCD_ShowNum(1, 7, Under, 3);
			if (counter_set_under == 1)
			{
				Under_Set();
				counter_set_under++;
			}
		}
		else if (counter_set_under == 0)
		{
			Under = 0;
		}
		
		if ((counter_set_timer == 0) && (counter_set_under == 0))
		{
			ds1302_read_realTime();
			//��������ʾ
			LCD_ShowNum(0, 0, TimeData.year, 4);
			LCD_ShowChar(0, 4, '/');
			LCD_ShowNum(0, 5, TimeData.month, 2);
			LCD_ShowChar(0, 7, '/');
			LCD_ShowNum(0, 8, TimeData.day, 2);
			
			LCD_ShowNum(1, 0, TimeData.hour, 2);
			LCD_ShowChar(1, 2, ':');
			LCD_ShowNum(1, 3, TimeData.minute, 2);
			LCD_ShowChar(1, 5, ':');
			LCD_ShowNum(1, 6, TimeData.second, 2);
			LCD_ShowChar(1, 8, ' ');
			LCD_ShowChar(1, 9, ' ');
			LCD_ShowChar(1, 10, ' ');
		
			//������������
			if (counter_set_date == 1)
			{
				ds1302_get_year();
				counter_set_date++;
			}
			else if (counter_set_date == 2)
			{
				ds1302_get_month();
				counter_set_date++;
			}
			else if (counter_set_date == 3)
			{
				ds1302_get_day();
				counter_set_date++;
			}
			
			if (counter_set_time == 1)
			{
				ds1302_get_hour();
				counter_set_time++;
			}
			else if (counter_set_time == 2)
			{
				ds1302_get_minute();
				counter_set_time++;
			}
			else if (counter_set_time == 3)
			{
				ds1302_get_second();
				counter_set_time++;
			}
		}
		DHT_Read();
		//�¶���ʾ
		LCD_Show_String(0, 11, (unsigned char *)"Temp");
		LCD_ShowNum(1, 11, Data[2], 2);
		LCD_ShowChar(1, 13, '.');
		LCD_ShowNum(1, 14, Data[3], 2);
		
	}
}
