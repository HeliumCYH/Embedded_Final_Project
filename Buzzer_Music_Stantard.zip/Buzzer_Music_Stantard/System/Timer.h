#ifndef __TIMER_H_
#define __TIMER_H_

void Timer_Init(void);
void Timer_Start(void);
void Timer_Stop(void);
void Timer_Clear(void);
void TIM2_IRQHandler(void);

#endif
