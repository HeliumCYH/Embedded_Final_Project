#include "stm32f10x.h"
#include "LCD1602v1.h"
#include "Buzzer.h"

extern uint8_t Under;
extern uint8_t counter_set_under;
extern uint8_t Num_Status[10];

void Under_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	
	TIM_TimeBaseInitTypeDef TIM_InitStructure;
	TIM_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_InitStructure.TIM_Period = 10000 - 1;
	TIM_InitStructure.TIM_Prescaler = 7200 - 1;
	TIM_InitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM3, &TIM_InitStructure);
	
	TIM_ClearFlag(TIM3, TIM_FLAG_Update);
	TIM_InternalClockConfig(TIM3);
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
}

void Under_Start(void)
{
	TIM_Cmd(TIM3, ENABLE);
}

void Under_Stop(void)
{
	TIM_Cmd(TIM3, DISABLE);
	Under = 0;
}

void Under_Set(void)
{
	int i = 0;
	while (i <= 2)
	{
		if (Num_Status[1])
		{
			 Under = 10 * Under + 1;
			i++;
			Num_Status[1] = 0;
		}
		else if (Num_Status[2])
		{
			 Under = 10 * Under + 2;
			i++;
			Num_Status[2] = 0;
		}
		else if (Num_Status[3])
		{
			 Under = 10 * Under + 3;
			i++;
			Num_Status[3] = 0;
		}
		else if (Num_Status[4])
		{
			 Under = 10 * Under + 4;
			i++;
			Num_Status[4] = 0;
		}
		else if (Num_Status[5])
		{
			 Under = 10 * Under + 5;
			i++;
			Num_Status[5] = 0;
		}
		else if (Num_Status[6])
		{
			 Under = 10 * Under + 6;
			i++;
			Num_Status[6] = 0;
		}
		else if (Num_Status[7])
		{
			 Under = 10 * Under + 7;
			i++;
			Num_Status[7] = 0;
		}
		else if (Num_Status[8])
		{
			 Under = 10 * Under + 8;
			i++;
			Num_Status[8] = 0;
		}
		else if (Num_Status[9])
		{
			 Under = 10 * Under + 9;
			i++;
			Num_Status[9] = 0;
		}
		else if (Num_Status[0])
		{
			 Under = 10 * Under + 0;
			i++;
			Num_Status[0] = 0;
		}
		LCD_ShowNum(1, 7, Under, 3);
	}
}

void TIM3_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
	{
		Under--;
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
		if ((Under == 0) && (counter_set_under != 0))
		{
			Under = 0;
			LCD_ShowNum(1, 7, Under, 3);
			play_music();
			Under_Stop();
		}
	}
}

