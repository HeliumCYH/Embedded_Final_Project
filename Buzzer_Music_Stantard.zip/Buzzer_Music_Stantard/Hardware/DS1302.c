#include "stm32f10x.h"
#include "DS1302.h"
#include "Delay.h"
#include "LCD1602v1.h"

extern uint8_t Num_Status[10];
extern struct TIMEData TimeRead;
extern struct TIMEData TimeData;
 
uint8_t read_time[7];
int dyear = 0;
int dmonth = 0;
int dday = 0;
int dhour = 0;
int dmin = 0;
int ds = 0;

extern struct TIMEData TimeData;
char DS1302_data_1[10];
char DS1302_data_2[8];

__IO uint8_t clockStatus;
 
 
void delay_us(uint32_t xus)
{
	
	SysTick->LOAD = 72 * xus * 2;				//????????
	SysTick->VAL = 0x00;					//???????
	SysTick->CTRL = 0x00000005;				//??????HCLK,?????
	while(!(SysTick->CTRL & 0x00010000));	//?????0
	SysTick->CTRL = 0x00000004;				//?????
	
}

void delay_ms(uint32_t xms)
{
	
	while(xms--)
	{
		delay_us(1000);
	}
	
}

 
void ds1302_DATAOUT_init(void)
{
  /* GPIO Ports Clock Enable */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
 
  /*Configure GPIO pin Output Level */
  GPIO_WriteBit(GPIOA,DATA_Pin, Bit_RESET);
	
	/*Configure GPIO pin : DATA_Pin */
	GPIO_InitTypeDef GPIO_InitStruct;

  GPIO_InitStruct.GPIO_Pin = DATA_Pin;   
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_OD;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = CLK_Pin;   
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = RST_Pin;   
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStruct);
}
 
void ds1302_DATAINPUT_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
 
  /* GPIO Ports Clock Enable */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
 
	 /*Configure GPIO pin : PA2 */
  GPIO_InitStruct.GPIO_Pin = DATA_Pin;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStruct);
}
 
 
/*
 * /��DS1302����һ�ֽ�����
 */
void ds1302_write_onebyte(uint8_t data)//��DS1302����һ�ֽ�����
{
	uint8_t count=0;
	ds1302_DATAOUT_init(); // I/O����Ϊ��� 
	
	GPIO_WriteBit(GPIOA, CLK_Pin, Bit_RESET);// ����ʱ��
	
	//
	delay_us(10);
	
	for(count=0;count<8;count++)
	{	
		GPIO_WriteBit(GPIOA,CLK_Pin, Bit_RESET);// ����ʱ��
		
		//
		delay_us(10);
		
		if(data&0x01)
		{
			GPIO_WriteBit(GPIOA,DATA_Pin, Bit_SET);
			
			//
			delay_us(10);
			
		}
		else
		{
			GPIO_WriteBit(GPIOA,DATA_Pin, Bit_RESET);
			
			//
			delay_us(10);
			
		}//��׼���������ٷ���
		GPIO_WriteBit(GPIOA,CLK_Pin, Bit_SET); //����ʱ���ߣ���������
		
		//
		delay_us(10);
		
		data>>=1; 
	}
	
}
 
/*
 * ��DS1302����ָ������
 */
void ds1302_wirte_rig(uint8_t address,uint8_t data)//��ָ���Ĵ�����ַ��������
{
	uint8_t temp1=address;
	uint8_t temp2=data;
	
	
	GPIO_WriteBit(GPIOA,RST_Pin, Bit_RESET); // ����RST
	
	//
	delay_us(10);
	
	GPIO_WriteBit(GPIOA,CLK_Pin, Bit_RESET);// ����ʱ��
	delay_us(1);
	GPIO_WriteBit(GPIOA,RST_Pin, Bit_SET); // ����RST
	delay_us(2);
	ds1302_write_onebyte(temp1); // д����
	ds1302_write_onebyte(temp2); // д����
	
	GPIO_WriteBit(GPIOA,RST_Pin, Bit_RESET); // ����RST
	GPIO_WriteBit(GPIOA,CLK_Pin, Bit_RESET);// ����ʱ��
	delay_us(2);
}
 
/*
 * ��DS1302��ȡ����
 */
uint8_t ds1302_read_rig(uint8_t address)//��ָ����ַ��ȡһ�ֽ�����
{
	uint8_t temp3=address;
	uint8_t count=0;
	uint8_t return_data=0x00;
	
	GPIO_WriteBit(GPIOA,RST_Pin, Bit_RESET); // ����RST
	
	//
	delay_us(10);
	
	GPIO_WriteBit(GPIOA,CLK_Pin, Bit_RESET);// ����ʱ��
	delay_us(3);
	GPIO_WriteBit(GPIOA,RST_Pin, Bit_SET); // ����RST
	delay_us(3);
	
	ds1302_write_onebyte(temp3); // д��ַ
	
	ds1302_DATAINPUT_init();//����I/O��Ϊ����
 
	for(count=0;count<8;count++)
	{
		delay_us(2);//ʹ��ƽ����һ��ʱ��
		return_data>>=1;
		GPIO_WriteBit(GPIOA,CLK_Pin, Bit_SET);// ����ʱ��
		delay_us(4);//ʹ�ߵ�ƽ����һ��ʱ��
		GPIO_WriteBit(GPIOA,CLK_Pin, Bit_RESET);// ����ʱ��
		delay_us(14);//��ʱ14us����ȥ��ȡ��ѹ������׼ȷ
		if(GPIO_ReadInputDataBit(GPIOA, DATA_Pin)) 
		{return_data=return_data|0x80;}
	}
	delay_us(2);
	GPIO_WriteBit(GPIOA,RST_Pin, Bit_RESET); // ����RST
	GPIO_WriteBit(GPIOA,DATA_Pin, Bit_RESET);	//	DATA����
	
	return return_data; // ��������
}
 
/*
 * ��ʼ��DS1302
ע�⣬д��ʱ��D0����Ϊ0
д��ʱ
�룺1000 0000��0x80
�֣�1000 0010��0x82
ʱ��1000 0100��0x84
�գ�1000 0110��0x86
�£�1000 1000��0x88
�ܣ�1000 1010��0x8a
�꣺1000 1100��0x8c
 */
void ds1302_init()
{
	//
	//ds1302_wirte_rig(0x8e,0x00);
	/*ע�����ݲ���*/
	//ds1302_wirte_rig(0x8e,0x00);//�ر�д����
	
	//ds1302_wirte_rig(0x80,0x54);//seconds37��
	//ds1302_wirte_rig(0x82,0x37);//minutes58��
	//ds1302_wirte_rig(0x84,0x20);//hours23ʱ
	ds1302_wirte_rig(0x86,0x05);//date5��
	ds1302_wirte_rig(0x88,0x09);//months9��
	//ds1302_wirte_rig(0x8a,0x03);//days������
	ds1302_wirte_rig(0x8c,0x24);//year2024��
	
	//ds1302_wirte_rig(0x80,0x19);
	
	//ds1302_wirte_rig(0x8e,0x80);//�ر�д����
	
}
void ds1302_data_init_time(void)
{
	//ds1302_wirte_rig(0x8e,0x00);//�ر�д����
	ds1302_wirte_rig(0x80,((TimeData.second / 10) % 10) << 4 | (TimeData.second  % 10));//seconds��
	ds1302_wirte_rig(0x82,((TimeData.minute / 10) % 10) << 4 | (TimeData.minute  % 10));//minutes��
	ds1302_wirte_rig(0x84,((TimeData.hour / 10) % 10) << 4 | (TimeData.hour  % 10));//hoursʱ
	ds1302_wirte_rig(0x86,((TimeData.day / 10) % 10) << 4 | (TimeData.day  % 10));//date��
	ds1302_wirte_rig(0x88,((TimeData.month / 10) % 10) << 4 | (TimeData.month  % 10));//months��
	ds1302_wirte_rig(0x8a,((TimeData.week / 10) % 10) << 4 | (TimeData.week  % 10));//days����
	uint8_t year_test = ((TimeData.year / 10) % 10) << 4 | (TimeData.year  % 10);
	ds1302_wirte_rig(0x8c,year_test);//year��
	
	//ds1302_wirte_rig(0x80,0x19);
	
	//ds1302_wirte_rig(0x8e,0x80);//�ر�д����
	
	//
	GPIO_WriteBit(GPIOA, DATA_Pin, Bit_RESET);
}

void ds1302_data_init(uint16_t cmd, uint16_t data){
	//ds1302_wirte_rig(0x8e,0x00);//�ر�д����
	ds1302_wirte_rig(cmd,data);//seconds37��
	//ds1302_wirte_rig(0x8e,0x80);//�ر�д����
}
 
/*
 * ��ȡDS1302����
ע�⣬����ʱ��D0����Ϊ1
��ȡʱ
�룺1000 0001��0x81
�֣�1000 0011��0x83
ʱ��1000 0101��0x85
�գ�1000 0111��0x87
�£�1000 1001��0x89
�ܣ�1000 1011��0x8b
�꣺1000 1101��0x8d
 */
void ds1302_read_time(void)
{
	read_time[0]=ds1302_read_rig(0x81);//����
	read_time[1]=ds1302_read_rig(0x83);//����
	read_time[2]=ds1302_read_rig(0x85);//��ʱ
	read_time[3]=ds1302_read_rig(0x87);//����
	read_time[4]=ds1302_read_rig(0x89);//����
	read_time[5]=ds1302_read_rig(0x8B);//������
	read_time[6]=ds1302_read_rig(0x8D);//����
}
 
void ds1302_read_realTime(void)
{
	ds1302_read_time();  //BCD��ת��Ϊ10����
	TimeData.second=(read_time[0]>>4)*10+(read_time[0]&0x0f) + ds;
	TimeData.minute=((read_time[1]>>4)&(0x07))*10+(read_time[1]&0x0f) + dmin;
	TimeData.hour=(read_time[2]>>4)*10+(read_time[2]&0x0f) + dhour;
	TimeData.day=(read_time[3]>>4)*10+(read_time[3]&0x0f) + dday;
	TimeData.month=(read_time[4]>>4)*10+(read_time[4]&0x0f) + dmonth;
	TimeData.week=read_time[5];
	TimeData.year=(read_time[6]>>4)*10+(read_time[6]&0x0f) + 2000 + dyear;
	
	// ��ͷ��ӵĴ���
	if (TimeData.second >= 60) {
	    TimeData.minute += TimeData.second / 60;
	    TimeData.second = TimeData.second % 60;
	}

	if (TimeData.minute >= 60) {
	    TimeData.hour += TimeData.minute / 60;
	    TimeData.minute = TimeData.minute % 60;
	}

	// Сʱ����Ĵ���
	if (TimeData.hour >= 24) {
		TimeData.day += TimeData.day/24;
	    TimeData.hour = TimeData.hour%24;
	    
	}

	// �ж��Ƿ�Ϊ����
	uint8_t isLeapYear = ((TimeData.year % 4 == 0 && TimeData.year % 100 != 0) || (TimeData.year % 400 == 0));

	// ÿ���������飬����0-11�ֱ��ʾ1�µ�12�£�ƽ�������������ͬ
	int daysInMonth[12] = {31, (isLeapYear ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

		// �����·ݺ�����
	if (TimeData.day > daysInMonth[TimeData.month - 1]) {
  	  TimeData.month += TimeData.month/daysInMonth[TimeData.month - 1];
		TimeData.day = TimeData.day%daysInMonth[TimeData.month - 1];
	}

	if (TimeData.month > 12) {
 	   
 	   TimeData.year += TimeData.month/12;
		TimeData.month = TimeData.month%12;
	}
	DS1302_data_1[0]='2';
	DS1302_data_1[1]='0';
	DS1302_data_1[2]='0'+(TimeData.year-208)/10;
	DS1302_data_1[3]='0'+(TimeData.year-208)%10;
	DS1302_data_1[4]='-';
	DS1302_data_1[5]='0'+(TimeData.month)/10;
	DS1302_data_1[6]='0'+(TimeData.month)%10;
	DS1302_data_1[7]='-';
	DS1302_data_1[8]='0'+(TimeData.day)/10;
	DS1302_data_1[9]='0'+(TimeData.day)%10;
	
	DS1302_data_2[0]='0'+(TimeData.hour)/10;
	DS1302_data_2[1]='0'+(TimeData.hour)%10;
	DS1302_data_2[2]=':';
	DS1302_data_2[3]='0'+(TimeData.minute)/10;
	DS1302_data_2[4]='0'+(TimeData.minute)%10;
	DS1302_data_2[5]=':';
	DS1302_data_2[6]='0'+(TimeData.second)/10;
	DS1302_data_2[7]='0'+(TimeData.second)%10;
	
	
	//
	GPIO_WriteBit(GPIOA, DATA_Pin, Bit_RESET);
}


void ds1302_start(void){
	ds1302_wirte_rig(0x8e,0x00);//�ر�д����
	ds1302_wirte_rig(0x80,((TimeData.second / 10) << 4 | (TimeData.second  % 10))& 0x7f);
	ds1302_wirte_rig(0x8e,0x80);//openд����
}
 void ds1302_stop(void){
	ds1302_wirte_rig(0x8e,0x00);//�ر�д����
	ds1302_wirte_rig(0x80,((TimeData.second / 10) << 4 | (TimeData.second  % 10))|(1 << 7));
	ds1302_wirte_rig(0x8e,0x80);//openд����
 }




void ds1302_get_year()
{
	TimeData.year = 0;
	int i = 0;
	while (i <= 3)
	{
		if (Num_Status[1])
		{
			 TimeData.year = 10 * TimeData.year + 1;
			i++;
			Num_Status[1] = 0;
		}
		else if (Num_Status[2])
		{
			 TimeData.year = 10 * TimeData.year + 2;
			i++;
			Num_Status[2] = 0;
		}
		else if (Num_Status[3])
		{
			 TimeData.year = 10 * TimeData.year + 3;
			i++;
			Num_Status[3] = 0;
		}
		else if (Num_Status[4])
		{
			 TimeData.year = 10 * TimeData.year + 4;
			i++;
			Num_Status[4] = 0;
		}
		else if (Num_Status[5])
		{
			 TimeData.year = 10 * TimeData.year + 5;
			i++;
			Num_Status[5] = 0;
		}
		else if (Num_Status[6])
		{
			 TimeData.year = 10 * TimeData.year + 6;
			i++;
			Num_Status[6] = 0;
		}
		else if (Num_Status[7])
		{
			 TimeData.year = 10 * TimeData.year + 7;
			i++;
			Num_Status[7] = 0;
		}
		else if (Num_Status[8])
		{
			 TimeData.year = 10 * TimeData.year + 8;
			i++;
			Num_Status[8] = 0;
		}
		else if (Num_Status[9])
		{
			 TimeData.year = 10 * TimeData.year + 9;
			i++;
			Num_Status[9] = 0;
		}
		else if (Num_Status[0])
		{
			 TimeData.year = 10 * TimeData.year + 0;
			i++;
			Num_Status[0] = 0;
		}
		LCD_ShowNum(0, 0, TimeData.year, 4);
	}
	ds1302_data_init_time();
}

void ds1302_get_month()
{
	TimeData.month = 0;
	int i = 0;
	while (i <= 1)
	{
		if (Num_Status[1])
		{
			 TimeData.month = 10 * TimeData.month + 1;
			i++;
			Num_Status[1] = 0;
		}
		else if (Num_Status[2])
		{
			 TimeData.month = 10 * TimeData.month + 2;
			i++;
			Num_Status[2] = 0;
		}
		else if (Num_Status[3])
		{
			 TimeData.month = 10 * TimeData.month + 3;
			i++;
			Num_Status[3] = 0;
		}
		else if (Num_Status[4])
		{
			 TimeData.month = 10 * TimeData.month + 4;
			i++;
			Num_Status[4] = 0;
		}
		else if (Num_Status[5])
		{
			 TimeData.month = 10 * TimeData.month + 5;
			i++;
			Num_Status[5] = 0;
		}
		else if (Num_Status[6])
		{
			 TimeData.month = 10 * TimeData.month + 6;
			i++;
			Num_Status[6] = 0;
		}
		else if (Num_Status[7])
		{
			 TimeData.month = 10 * TimeData.month + 7;
			i++;
			Num_Status[7] = 0;
		}
		else if (Num_Status[8])
		{
			 TimeData.month = 10 * TimeData.month + 8;
			i++;
			Num_Status[8] = 0;
		}
		else if (Num_Status[9])
		{
			 TimeData.month = 10 * TimeData.month + 9;
			i++;
			Num_Status[9] = 0;
		}
		else if (Num_Status[0])
		{
			 TimeData.month = 10 * TimeData.month + 0;
			i++;
			Num_Status[0] = 0;
		}
		LCD_ShowNum(0, 5, TimeData.month, 2);
	}
	ds1302_data_init_time();
}

void ds1302_get_day()
{
	TimeData.day = 0;
	int i = 0;
	while (i <= 1)
	{
		if (Num_Status[1])
		{
			 TimeData.day = 10 * TimeData.day + 1;
			i++;
			Num_Status[1] = 0;
		}
		else if (Num_Status[2])
		{
			 TimeData.day = 10 * TimeData.day + 2;
			i++;
			Num_Status[2] = 0;
		}
		else if (Num_Status[3])
		{
			 TimeData.day = 10 * TimeData.day + 3;
			i++;
			Num_Status[3] = 0;
		}
		else if (Num_Status[4])
		{
			 TimeData.day = 10 * TimeData.day + 4;
			i++;
			Num_Status[4] = 0;
		}
		else if (Num_Status[5])
		{
			 TimeData.day = 10 * TimeData.day + 5;
			i++;
			Num_Status[5] = 0;
		}
		else if (Num_Status[6])
		{
			 TimeData.day = 10 * TimeData.day + 6;
			i++;
			Num_Status[6] = 0;
		}
		else if (Num_Status[7])
		{
			 TimeData.day = 10 * TimeData.day + 7;
			i++;
			Num_Status[7] = 0;
		}
		else if (Num_Status[8])
		{
			 TimeData.day = 10 * TimeData.day + 8;
			i++;
			Num_Status[8] = 0;
		}
		else if (Num_Status[9])
		{
			 TimeData.day = 10 * TimeData.day + 9;
			i++;
			Num_Status[9] = 0;
		}
		else if (Num_Status[0])
		{
			 TimeData.day = 10 * TimeData.day + 0;
			i++;
			Num_Status[0] = 0;
		}
		LCD_ShowNum(0, 8, TimeData.day, 2);
	}
	ds1302_data_init_time();
}

void ds1302_get_hour()
{
	TimeData.hour = 0;
	int i = 0;
	while (i <= 1)
	{
		if (Num_Status[1])
		{
			 TimeData.hour = 10 * TimeData.hour + 1;
			i++;
			Num_Status[1] = 0;
		}
		else if (Num_Status[2])
		{
			 TimeData.hour = 10 * TimeData.hour + 2;
			i++;
			Num_Status[2] = 0;
		}
		else if (Num_Status[3])
		{
			 TimeData.hour = 10 * TimeData.hour + 3;
			i++;
			Num_Status[3] = 0;
		}
		else if (Num_Status[4])
		{
			 TimeData.hour = 10 * TimeData.hour + 4;
			i++;
			Num_Status[4] = 0;
		}
		else if (Num_Status[5])
		{
			 TimeData.hour = 10 * TimeData.hour + 5;
			i++;
			Num_Status[5] = 0;
		}
		else if (Num_Status[6])
		{
			 TimeData.hour = 10 * TimeData.hour + 6;
			i++;
			Num_Status[6] = 0;
		}
		else if (Num_Status[7])
		{
			 TimeData.hour = 10 * TimeData.hour + 7;
			i++;
			Num_Status[7] = 0;
		}
		else if (Num_Status[8])
		{
			 TimeData.hour = 10 * TimeData.hour + 8;
			i++;
			Num_Status[8] = 0;
		}
		else if (Num_Status[9])
		{
			 TimeData.hour = 10 * TimeData.hour + 9;
			i++;
			Num_Status[9] = 0;
		}
		else if (Num_Status[0])
		{
			 TimeData.hour = 10 * TimeData.hour + 0;
			i++;
			Num_Status[0] = 0;
		}
		LCD_ShowNum(1, 0, TimeData.hour, 2);
	}
	ds1302_data_init_time();
}

void ds1302_get_minute()
{
	TimeData.minute = 0;
	int i = 0;
	while (i <= 1)
	{
		if (Num_Status[1])
		{
			 TimeData.minute = 10 * TimeData.minute + 1;
			i++;
			Num_Status[1] = 0;
		}
		else if (Num_Status[2])
		{
			 TimeData.minute = 10 * TimeData.minute + 2;
			i++;
			Num_Status[2] = 0;
		}
		else if (Num_Status[3])
		{
			 TimeData.minute = 10 * TimeData.minute + 3;
			i++;
			Num_Status[3] = 0;
		}
		else if (Num_Status[4])
		{
			 TimeData.minute = 10 * TimeData.minute + 4;
			i++;
			Num_Status[4] = 0;
		}
		else if (Num_Status[5])
		{
			 TimeData.minute = 10 * TimeData.minute + 5;
			i++;
			Num_Status[5] = 0;
		}
		else if (Num_Status[6])
		{
			 TimeData.minute = 10 * TimeData.minute + 6;
			i++;
			Num_Status[6] = 0;
		}
		else if (Num_Status[7])
		{
			 TimeData.minute = 10 * TimeData.minute + 7;
			i++;
			Num_Status[7] = 0;
		}
		else if (Num_Status[8])
		{
			 TimeData.minute = 10 * TimeData.minute + 8;
			i++;
			Num_Status[8] = 0;
		}
		else if (Num_Status[9])
		{
			 TimeData.minute = 10 * TimeData.minute + 9;
			i++;
			Num_Status[9] = 0;
		}
		else if (Num_Status[0])
		{
			 TimeData.minute = 10 * TimeData.minute + 0;
			i++;
			Num_Status[0] = 0;
		}
		LCD_ShowNum(1, 3, TimeData.minute, 2);
	}
	ds1302_data_init_time();
}

void ds1302_get_second()
{
	TimeData.second = 0;
	int i = 0;
	while (i <= 1)
	{
		if (Num_Status[1])
		{
			 TimeData.second = 10 * TimeData.second + 1;
			i++;
			Num_Status[1] = 0;
		}
		else if (Num_Status[2])
		{
			 TimeData.second = 10 * TimeData.second + 2;
			i++;
			Num_Status[2] = 0;
		}
		else if (Num_Status[3])
		{
			 TimeData.second = 10 * TimeData.second + 3;
			i++;
			Num_Status[3] = 0;
		}
		else if (Num_Status[4])
		{
			 TimeData.second = 10 * TimeData.second + 4;
			i++;
			Num_Status[4] = 0;
		}
		else if (Num_Status[5])
		{
			 TimeData.second = 10 * TimeData.second + 5;
			i++;
			Num_Status[5] = 0;
		}
		else if (Num_Status[6])
		{
			 TimeData.second = 10 * TimeData.second + 6;
			i++;
			Num_Status[6] = 0;
		}
		else if (Num_Status[7])
		{
			 TimeData.second = 10 * TimeData.second + 7;
			i++;
			Num_Status[7] = 0;
		}
		else if (Num_Status[8])
		{
			 TimeData.second = 10 * TimeData.second + 8;
			i++;
			Num_Status[8] = 0;
		}
		else if (Num_Status[9])
		{
			 TimeData.second = 10 * TimeData.second + 9;
			i++;
			Num_Status[9] = 0;
		}
		else if (Num_Status[0])
		{
			 TimeData.second = 10 * TimeData.second + 0;
			i++;
			Num_Status[0] = 0;
		}
		LCD_ShowNum(1, 6, TimeData.second, 2);
	}
	ds1302_data_init_time();
}


