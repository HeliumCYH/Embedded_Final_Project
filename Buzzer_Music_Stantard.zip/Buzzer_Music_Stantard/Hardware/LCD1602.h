#ifndef __LCD1602_H_
#define __LCD1602_H_


void LCD1602_Init(void);
void LCD1602_WaitReady(void);
void LCD1602_WriteCmd(uint16_t cmd);
void LCD1602_WriteData(uint16_t data);
void LCD1620_SetAddress(unsigned char x,unsigned char y);
void LCD1602_ShowStr(unsigned char x,unsigned char y,unsigned char *str);
void LCD1602_ShowChar(unsigned char x,unsigned char y,unsigned char date);
void LCD1602_ShowNum(unsigned char x,unsigned char y,unsigned char *str,unsigned char i);
void WUserImg(unsigned char pos,unsigned char *ImgInfo);

#endif
