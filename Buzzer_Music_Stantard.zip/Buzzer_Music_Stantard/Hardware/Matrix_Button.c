#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Timer.h"
#include "Under.h"
#include "DS1302.h"
#include "LCD1602v1.h"
#include "Buzzer.h"

extern uint8_t Num_Status[10];
extern int x, y;
extern uint16_t Under;
uint8_t counter_set_timer;
uint8_t counter_set_under;
//DS1302��־λ
uint8_t counter_set_date;
uint8_t counter_set_time;

extern struct TIMEData TimeData;

//Buzzer��־λ
extern uint8_t Buzzer_Sta;

//��ʱ������
extern uint16_t Num;
extern uint16_t counter_ms, counter_second, counter_minute;

//pos���
static uint8_t pos;

void Matrix_Button_Init(void)
{
	//GPIO_Init
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
 	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
 	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	//AFIO_Init
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	
	//EXTI_Init
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource4);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource5);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource6);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource7);
	
	EXTI_InitTypeDef EXTI_Init_Structure;
	EXTI_Init_Structure.EXTI_Line = EXTI_Line4;
	EXTI_Init_Structure.EXTI_LineCmd = ENABLE;
	EXTI_Init_Structure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_Init_Structure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&EXTI_Init_Structure);
	
	EXTI_Init_Structure.EXTI_Line = EXTI_Line5;
	EXTI_Init_Structure.EXTI_LineCmd = ENABLE;
	EXTI_Init_Structure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_Init_Structure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&EXTI_Init_Structure);
	
	EXTI_Init_Structure.EXTI_Line = EXTI_Line6;
	EXTI_Init_Structure.EXTI_LineCmd = ENABLE;
	EXTI_Init_Structure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_Init_Structure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&EXTI_Init_Structure);
	
	EXTI_Init_Structure.EXTI_Line = EXTI_Line7;
	EXTI_Init_Structure.EXTI_LineCmd = ENABLE;
	EXTI_Init_Structure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_Init_Structure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&EXTI_Init_Structure);
	
	//����NVIC
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	//��������Systic�ж����ȼ�
	NVIC_SetPriority(SysTick_IRQn, 0);
	
	//���Ƴ�ʼ��ƽ����
	GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
	GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_RESET);
	GPIO_WriteBit(GPIOA, GPIO_Pin_2, Bit_RESET);
	GPIO_WriteBit(GPIOA, GPIO_Pin_3, Bit_RESET);
}

uint16_t GPIO_y[5] = {0, GPIO_Pin_4, GPIO_Pin_5, GPIO_Pin_6, GPIO_Pin_7};
uint16_t GPIO_x[4] = {GPIO_Pin_0, GPIO_Pin_1, GPIO_Pin_2, GPIO_Pin_3};

uint8_t Matrix_GetPosition(uint8_t y)
{
	uint8_t pos1 = 0;
	
	uint16_t y_base = GPIO_y[y];
	uint8_t i = 0;
	for (i = 0; i <= 3; i++)
	{
		//������ɨ��
		uint8_t sta1 = GPIO_ReadInputDataBit(GPIOA, y_base);
		GPIO_WriteBit(GPIOA, GPIO_x[i], Bit_SET);
		uint8_t sta2 = GPIO_ReadInputDataBit(GPIOA, y_base);
		GPIO_WriteBit(GPIOA, GPIO_x[i], Bit_RESET);
		if (sta1 ^ sta2)
		{
			pos1 = (4 * i) + y;
			break;
		}
	}
	GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
	GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_RESET);
	GPIO_WriteBit(GPIOA, GPIO_Pin_2, Bit_RESET);
	GPIO_WriteBit(GPIOA, GPIO_Pin_3, Bit_RESET);
	return pos1;
}

void EXTI4_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line4) == SET)
	{
		//delayȥ��
		Delay_ms(25);
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4) == 0)
		{
			pos = Matrix_GetPosition(1);
			//���ú���ִ�ж�Ӧ��������
			if (pos == 1)
			{
				counter_set_timer++;
				counter_set_timer = counter_set_timer % 3;
				if (counter_set_timer == 1)
				{
					Timer_Init();
					Timer_Start();
				}
				else if (counter_set_timer == 2)
				{
					Timer_Stop();
					counter_ms = Num % 1000;
					counter_second = (Num / 1000) % 60;
					counter_minute = Num / 1000 / 60;
		
					LCD_ShowNum(1, 0, counter_minute, 1);
					LCD_ShowNum(1, 1, counter_second, 2);
					LCD_ShowNum(1, 3, counter_ms, 3);
					LCD1602_ClearScreen();
				}
				else if (counter_set_timer == 0)
				{
					Timer_Clear();
				}
			}
			else if (pos == 5)
			{
				//����ʱ����
				counter_set_under++;
				counter_set_under = counter_set_under % 4;
				if (counter_set_under == 1)
				{
					Under = 0;
				}
				else if (counter_set_under == 3)
				{
					Buzzer_Sta = 1;
					Under_Init();
					Under_Start();
				}
				else if (counter_set_under == 0)
				{
					Under_Stop();
					Under = 0;
					Buzzer_Sta = 0;
					//LCD_ShowNum(1, 7, Under, 3);
					//LCD1602_ClearScreen();
				}
			}
			else if (pos == 9)
			{
				//����
				LCD1602_ClearScreen();
			}
			else if (pos == 13)
			{
				//DS1302д��������
				counter_set_date++;
				counter_set_date = counter_set_date % 4;
			}
		}
		//���ֵ�����̧��
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4) == 0);
		//delayȥ��
		Delay_ms(25);
		//�����־λ
		EXTI_ClearITPendingBit(EXTI_Line4);
		/*
		static uint16_t x;
		x = EXTI_GetITStatus(EXTI_Line4);
		*/
	}
	
}

void EXTI9_5_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line5) == SET)
	{
		//delayȥ��
		Delay_ms(25);
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5) == 0)
		{
			pos = Matrix_GetPosition(2);
			//���ú���ִ�ж�Ӧ��������
			if (pos == 2)
			{
				if ((counter_set_date || counter_set_time  || counter_set_under))
				{
					Num_Status[1] = 1;
				}
			}
			else if (pos == 6)
			{
				if ((counter_set_date || counter_set_time  || counter_set_under))
				{
					Num_Status[4] = 1;
				}
			}
			else if (pos == 10)
			{
				if ((counter_set_date || counter_set_time  || counter_set_under))
				{
					Num_Status[7] = 1;
				}
			}
			else if (pos == 14)
			{
				//DS1302д��ʱ����
				counter_set_time++;
				counter_set_time = counter_set_time % 4;
			}
		}
		//���ֵ�����̧��
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5) == 0);
		//delayȥ��
		Delay_ms(25);
		//�����־λ
		EXTI_ClearITPendingBit(EXTI_Line5);
	}
	else if(EXTI_GetITStatus(EXTI_Line6) == SET)
	{
		//delayȥ��
		Delay_ms(25);
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0)
		{
			pos = Matrix_GetPosition(3);
			//���ú���ִ�ж�Ӧ��������
			if (pos == 3)
			{
				if ((counter_set_date || counter_set_time  || counter_set_under))
				{
					Num_Status[2] = 1;
				}
			}
			else if (pos == 7)
			{
				if ((counter_set_date || counter_set_time  || counter_set_under))
				{
					Num_Status[5] = 1;
				}
			}
			else if (pos == 11)
			{
				if ((counter_set_date || counter_set_time  || counter_set_under))
				{
					Num_Status[8] = 1;
				}
			}
			else if (pos == 15)
			{
				if ((counter_set_date || counter_set_time  || counter_set_under))
				{
					Num_Status[0] = 1;
				}
			}
		}
		//���ֵ�����̧��
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0);
		//delayȥ��
		Delay_ms(25);
		//�����־λ
		EXTI_ClearITPendingBit(EXTI_Line6);
	}
	else if(EXTI_GetITStatus(EXTI_Line7) == SET)
	{
		//delayȥ��
		Delay_ms(25);
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0)
		{
			pos = Matrix_GetPosition(4);
			//���ú���ִ�ж�Ӧ��������
			if (pos == 4)
			{
				if ((counter_set_date || counter_set_time  || counter_set_under))
				{
					Num_Status[3] = 1;
				}
			}
			else if (pos == 8)
			{
				if ((counter_set_date || counter_set_time  || counter_set_under))
				{
					Num_Status[6] = 1;
				}
			}
			else if (pos == 12)
			{
				if ((counter_set_date || counter_set_time  || counter_set_under))
				{
					Num_Status[9] = 1;
				}
			}
			else if (pos == 16)
			{
				//
				
			}
		}
		//���ֵ�����̧��
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0);
		//delayȥ��
		Delay_ms(25);
		//�����־λ
		EXTI_ClearITPendingBit(EXTI_Line7);
	}
}

