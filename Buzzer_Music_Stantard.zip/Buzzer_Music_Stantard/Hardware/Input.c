#include "stm32f10x.h"
#include "Delay.h"

/*
p:'A'/'B'/'C'
x:引脚数
*/
void IPU(uint8_t p, uint8_t x)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	switch(p)
	{
		case 'A':RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); break;
		case 'B':RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); break;
		case 'C':RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE); break;
		default:break;
	}
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	switch(x)
	{
		case 0: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;break;
		case 1: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;break;
		case 2: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;break;
		case 3: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;break;
		case 4: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;break;
		case 5: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;break;
		case 6: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;break;
		case 7: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;break;
		case 8: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;break;
		case 9: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;break;
		case 10: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;break;
		case 11: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;break;
		case 12: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;break;
		case 13: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;break;
		default: break;
	}
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	switch(p)
	{
		case 'A':GPIO_Init(GPIOA, &GPIO_InitStructure); break;
		case 'B':GPIO_Init(GPIOB, &GPIO_InitStructure); break;
		case 'C':GPIO_Init(GPIOC, &GPIO_InitStructure); break;
		default:break;
	}
}

void IPD(uint8_t p, uint8_t x)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	switch(p)
	{
		case 'A':RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); break;
		case 'B':RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); break;
		case 'C':RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE); break;
		default:break;
	}
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	switch(x)
	{
		case 0: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;break;
		case 1: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;break;
		case 2: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;break;
		case 3: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;break;
		case 4: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;break;
		case 5: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;break;
		case 6: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;break;
		case 7: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;break;
		case 8: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;break;
		case 9: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;break;
		case 10: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;break;
		case 11: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;break;
		case 12: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;break;
		case 13: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;break;
		default: break;
	}
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	switch(p)
	{
		case 'A':GPIO_Init(GPIOA, &GPIO_InitStructure); break;
		case 'B':GPIO_Init(GPIOB, &GPIO_InitStructure); break;
		case 'C':GPIO_Init(GPIOC, &GPIO_InitStructure); break;
		default:break;
	}
}

uint8_t IPUA_GetNum(uint8_t x)
{
	uint8_t ans = 1;
	switch(x)
	{
		case 0: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 1: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 2: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 3: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 4: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 5: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 6: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 7: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 8: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 9: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_9) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_9) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 10: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_10) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_10) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 11: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 12: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_12) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_12) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		case 13: if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_13) == 0)
						{
							Delay_ms(20);
							while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_13) == 1)
							{
							}
							Delay_ms(20);
							ans = 0;
						}break;
		default: break;
	}
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0)
	{
		Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 1)
		{
		}
		Delay_ms(20);
		ans = 0;
	}
	return ans;
}
