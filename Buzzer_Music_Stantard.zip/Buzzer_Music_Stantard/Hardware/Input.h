#ifndef __INPUT_H_
#define __INPUT_H_

void IPU(uint8_t p, uint8_t x);
void IPD(uint8_t p, uint8_t x);
uint8_t IPUA_GetNum(uint8_t x);

#endif
