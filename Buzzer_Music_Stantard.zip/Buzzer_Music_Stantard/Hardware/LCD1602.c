#include "stm32f10x.h"
#include "LCD1602.h"
#include "Delay.h"

//���ź궨��
#define LCD1602_Pin_RS GPIO_Pin_1
#define LCD1602_Pin_RW GPIO_Pin_2
#define LCD1602_Pin_EN GPIO_Pin_0
#define LCD1602_Pin_D7 GPIO_Pin_15
#define LCD1602_Pin_IO (GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15)

//PPָ��궨��
#define  LCD1602_I0_SET GPIO_WriteBit(GPIOB, LCD1602_Pin_IO, Bit_SET)
#define  LCD1602_RS_SET   GPIO_WriteBit(GPIOB, LCD1602_Pin_RS, Bit_SET)
#define  LCD1602_RS_RESET GPIO_WriteBit(GPIOB, LCD1602_Pin_RS, Bit_RESET)
#define  LCD1602_RW_SET   GPIO_WriteBit(GPIOB, LCD1602_Pin_RW, Bit_SET)
#define  LCD1602_RW_RESET GPIO_WriteBit(GPIOB, LCD1602_Pin_RW, Bit_RESET)
#define  LCD1602_EN_SET   GPIO_WriteBit(GPIOB, LCD1602_Pin_EN, Bit_SET)
#define  LCD1602_EN_RESET GPIO_WriteBit(GPIOB, LCD1602_Pin_EN, Bit_RESET)

void LCD1602_GPIO_Init_Out(void)
{
	//DATA������
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Pin = LCD1602_Pin_IO;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	//���ƽ�����
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = LCD1602_Pin_RS | LCD1602_Pin_RW | LCD1602_Pin_EN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void LCD1602_GPIO_Init_In(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin = LCD1602_Pin_D7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void LCD1602_WaitReady(void)
{
	uint8_t sta = 0;
  LCD1602_GPIO_Init_Out();
	GPIOB->ODR = ((0xff00 << 8));
  LCD1602_RS_RESET;
	LCD1602_RW_SET;
	LCD1602_EN_SET;
	LCD1602_GPIO_Init_In();
	do{
		LCD1602_EN_SET;
		sta = GPIO_ReadInputDataBit(GPIOB, LCD1602_Pin_D7);
		LCD1602_EN_RESET;
	  }
		while(!sta);
		LCD1602_EN_RESET;
		LCD1602_GPIO_Init_Out();
}

void LCD1602_WriteCmd(uint16_t cmd)
{
	//LCD1602_WaitReady();
	LCD1602_RS_RESET;
	LCD1602_RW_RESET;
	GPIOB->ODR &=((cmd << 8));
	LCD1602_EN_SET;
	Delay_ms(5);
	LCD1602_EN_RESET;
	Delay_ms(5);
}

void LCD1602_WriteData(uint16_t data)
{
	LCD1602_WaitReady();
	LCD1602_RS_SET;
	LCD1602_RW_RESET;
	GPIOB->ODR &=((data << 8)|0x0000);
	LCD1602_EN_SET;
	Delay_ms(5);
	LCD1602_EN_RESET;
	Delay_ms(5);
}

void LCD1620_SetAddress(unsigned char x,unsigned char y)
{
	if(y == 0)
	LCD1602_WriteCmd(0x80 | x);
	else 
	LCD1602_WriteCmd(0x80 | 0x40 | x);
}

void LCD1602_ShowStr(unsigned char x,unsigned char y,unsigned char *str)
{
	LCD1620_SetAddress(x,y);
	while(*str != '\0')
	LCD1602_WriteData(*str++);
}

void LCD1602_ShowChar(unsigned char x,unsigned char y,unsigned char date)
{
	LCD1620_SetAddress(x,y);
	LCD1602_WriteData(date);
}
               
void LCD1602_ShowNum(unsigned char x,unsigned char y,unsigned char *str,unsigned char i)
{
	LCD1620_SetAddress(x,y);
	str = str+ i;
	LCD1602_WriteData(*str);
}
/*
void WUserImg(unsigned char pos,unsigned char *ImgInfo)
{
	unsigned char cgramAddr;
	
	if( pos <= 1 ) cgramAddr = 0x40;
	if( pos > 1 && pos <= 3 ) cgramAddr = 0x50;
	if( pos > 3 && pos <= 5 ) cgramAddr = 0x60;
	if( pos > 5 && pos <= 7 ) cgramAddr = 0x70;

	LCD1602_WriteCmd( (cgramAddr + (pos%2) * 8) );
	
	while( *ImgInfo != '\0' )
	{
		LCD1602_WriteData( *ImgInfo );
		ImgInfo++;
	}
}
*/
void LCD1602_Init(void)
{
	LCD1602_GPIO_Init_Out();
	LCD1602_WriteCmd(0x38);
	LCD1602_WriteCmd(0x0c);
	LCD1602_WriteCmd(0x06);
	LCD1602_WriteCmd(0x01);
}

