#ifndef __COUNT_SENSOR_H
#define __COUNT_SENSOR_H

void EXTIInit(void);
uint8_t Get_CountNum(void);

#endif
