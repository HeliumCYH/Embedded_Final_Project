#ifndef __LED_H
#define __LED_H

void PP_Init(uint8_t p,uint8_t x);

#endif
