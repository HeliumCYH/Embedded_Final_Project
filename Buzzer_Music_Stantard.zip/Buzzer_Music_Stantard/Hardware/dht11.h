#ifndef __DHT11_H
#define __DHT11_H

#define DHT11_GPIO_Pin GPIO_Pin_11
#define DH11_GPIO_Port GPIOA

extern uint8_t Data[5];
void DHT_GPIO_SET_OUTPUT(void);
void DHT_GPIO_SET_INPUT(void);
uint8_t DHT_Read_Byte(void);
uint8_t DHT_Read(void);

#endif
