#include "stm32f10x.h"                  // Device header

/*
p:'A'/'B'/'C'
x:引脚数
*/
void PP_Init(uint8_t p,uint8_t x)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	switch(p)
	{
		case 'A':RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); break;
		case 'B':RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); break;
		case 'C':RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE); break;
		default:break;
	}
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	switch(x)
	{
		case 0: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;break;
		case 1: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;break;
		case 2: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;break;
		case 3: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;break;
		case 4: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;break;
		case 5: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;break;
		case 6: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;break;
		case 7: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;break;
		case 8: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;break;
		case 9: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;break;
		case 10: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;break;
		case 11: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;break;
		case 12: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;break;
		case 13: GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;break;
		default: break;
	}
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	switch(p)
	{
		case 'A':GPIO_Init(GPIOA, &GPIO_InitStructure); break;
		case 'B':GPIO_Init(GPIOB, &GPIO_InitStructure); break;
		case 'C':GPIO_Init(GPIOC, &GPIO_InitStructure); break;
		default:break;
	}
}
