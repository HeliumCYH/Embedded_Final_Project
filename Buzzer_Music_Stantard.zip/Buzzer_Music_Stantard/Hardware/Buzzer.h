#ifndef __BUZZER_H_
#define __BUZZER_H_

void Buzzer_Init(void);
void Buzzer_High(void);
void Buzzer_Low(void);
void Sound(uint16_t frq);
void play_music(void);

#endif
