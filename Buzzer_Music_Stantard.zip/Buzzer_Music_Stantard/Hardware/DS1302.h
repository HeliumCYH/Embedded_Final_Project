#ifndef __DS1302_H__
#define __DS1302_H__
/***DS1302????****************************/
//CLK--->PA9
//IO---->PA8
//RES--->PA10
/****************************/

/********************/
void ds1302_DATAOUT_init(void);
void ds1302_DATAINPUT_init(void);
void ds1302_data_init(uint16_t cmd, uint16_t data);
void ds1302_write_onebyte(uint8_t data);
void ds1302_wirte_rig(uint8_t address,uint8_t data);
uint8_t ds1302_read_rig(uint8_t address);
void ds1302_init(void);
void ds1302_data_init_time(void);
void ds1302_read_time(void);
void ds1302_read_realTime(void);
void ds1302_stop(void);
void ds1302_start(void);

struct TIMEData
{
	uint16_t second;
	uint16_t minute;
	uint16_t hour;
	uint16_t day;
	uint16_t week;
	uint16_t month;
	uint16_t year;
};
void ds1302_get_year(void);
void ds1302_get_month(void);
void ds1302_get_day(void);
void ds1302_get_hour(void);
void ds1302_get_minute(void);
void ds1302_get_second(void);
//д�Ĵ���λ��ַ�궨��
#define  DS1302W_SECOND		0X80
#define  DS1302W_MINUTE  	0X82
#define  DS1302W_HOUR		0X84
#define  DS1302W_DATE        0X86
#define  DS1302W_MONTH		0X88
#define  DS1302W_DAY         0X86
#define  DS1302W_YEAR        0X8C
#define  DS1302W_WP          0X8E
//���Ĵ�����ַ�궨��
#define  DS1302R_SECOND		0X81
#define  DS1302R_MINUTE  	0X83
#define  DS1302R_HOUR		0X85
#define  DS1302R_DATE        0X87
#define  DS1302R_MONTH		0X89
#define  DS1302R_DAY         0X87
#define  DS1302R_YEAR        0X8D
//���ź궨��
#define DATA_Pin GPIO_Pin_8
#define CLK_Pin GPIO_Pin_9
#define RST_Pin GPIO_Pin_10
#endif
