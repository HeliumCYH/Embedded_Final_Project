#ifndef __MATRIX_BUTTON_H_
#define __MATRIX_BUTTON_H_

void Matrix_Button_Init(void);
uint8_t Matrix_GetPosition(void);

#endif
