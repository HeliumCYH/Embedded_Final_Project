#include "stm32f10x.h"
#include "Delay.h"

uint8_t Buzzer_Sta = 0;

void Buzzer_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void Buzzer_High(void)
{
	GPIO_WriteBit(GPIOB, GPIO_Pin_7, Bit_SET);
}

void Buzzer_Low(void)
{
	GPIO_WriteBit(GPIOB, GPIO_Pin_7, Bit_RESET);
}
 
void Sound(uint16_t frq)
{
	uint32_t time;
	if(frq != 1000)
	{
//		time = 500000/((uint32_t)frq);
		time = 100000/((uint32_t)frq);
//		PBeep = 1;
		Buzzer_High();//?????--???????????,??????????gpio???1
 
		Delay_us(time);
//		PBeep = 0;
		Buzzer_Low();//?????--???????????,??????????gpio???0
		Delay_us(time);
	}else
		Delay_us(1000);
}

void play_music(void)
{
	//             ?7  1   2   3   4   5   6   7  ?1 ?2  ?3 ?4 ?5 ???
	const uint16_t tone[] = {247,262,294,330,349,392,440,494,523,587,659,698,784,1000};//?????
 
	//???
	/*
		uint8_t music[]={3,5,8,6,5,13,//??
	                3,5,6,8,5,13,
	                8,10,9,8,9,8,6,8,5,13,
					3,5,6,5,6,8,9,5,6,13,
					3,2,1,2,13,
					2,2,3,5,5,8,2,3,5,13};
		uint8_t time[] ={2,2,2,2,6,4,//??  
				2,2,2,2,6,4,
                6,2,4,4,2,2,2,2,6,4,
				6,2,4,2,2,4,2,2,6,4,
				2,2,4,6,4,
				4,2,2,4,4,4,2,2,6,4};
	*/
//	u8 music[]={13,1,2,3,4,5,6,7,8};//?????
//	u8 time[] ={4, 4,4,4,4,4,4,4,4};
 //���У�� time*2
	/*
	uint8_t music[]={
		3,3,3,
		5,1,
		2,4,
		3,5,
		6,5,4,
		6,0,
		6,7,6,
		5,5,
		8,7,6,
		5,4,3,
		6,2,3,
		2,0,
		3,3,6,
		6,5,5,
		5,5,8,
		7,7,8,
		9,8,7,6,5,
		2,6,0,
		1
		
	                };
		uint8_t time[] ={
			2,2,2,
			4,2, 
			4,2,
			4,2,
			2,2,2,
			4,2,
			2,2,2,
			4,2,
			4,1,1,
			3,1,2,
			2,2,2,
			4,2,
			2,2,2,
			3,1,2,
			2,2,2,
			4,1,1,
			1,1,1,1,2,
			2,2,2,
			6
			
				};
			*/
		//ʹһ�������ڰ���
		/*
			uint8_t music[]={
			3,3,3,3,5,
			4,3,5,
			3,3,3,3,
			4,
			3,3,3,3,5,
			4,3,4,5,
			5,1,1,2,1
	                };
		uint8_t time[] ={
			2,2,2,1,3,
			1,4,1,
			2,2,2,1,
			5,
			2,2,2,1,3,
			1,3,1,1,
			3,1,1,1,4
				};
		*/
		//time * 4
		uint8_t music[]={
			10,10,10,10,12,
			11,10,5,
			10,10,10,10,
			11,
			10,10,10,10,12,
			11,10,11,12,
			12,8,8,9,8
	                };
		uint8_t time[] ={
			2,2,2,1,3,
			1,4,1,
			2,2,2,1,
			7,
			2,2,2,1,3,
			1,3,1,1,
			3,1,1,1,4
				};
				
	uint32_t yanshi;
	uint16_t i,e;
	yanshi = 2;//10;  4;  2
	for(i=0;i<sizeof(music)/sizeof(music[0]);i++){
		if (Buzzer_Sta == 0)
		{
			break;
		}
		for(e=0;e<((uint16_t)time[i])*4*tone[music[i]]/yanshi;e++){
			Sound((uint32_t)tone[music[i]]);
		}	
		Delay_ms(20);
	}
}

 
