
#include "LCD1602_New.h"

void delay_us(unsigned int us){
	unsigned int  i;
	
	do{
		i = 10;
		while(i--) __nop();
	} while (--us);

}
/***********************************GPIO???********************************************/
void GPIO_INIT(void){		//GPIO???
	GPIO_InitTypeDef PB;
	GPIO_InitTypeDef PA;
	
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);	//??jtag,????????????????
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE );
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE );		//??GPIOB~B
	//RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC, ENABLE );
	
	PB.GPIO_Pin = LCD1602_Pin_RS | LCD1602_Pin_RW | LCD1602_Pin_EN;
	PB.GPIO_Mode = GPIO_Mode_Out_PP;
	PB.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &PB);
	
	PA.GPIO_Pin = LCD1602_Pin_IO;
	PA.GPIO_Mode = GPIO_Mode_Out_PP;
	PA.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &PA);
	
}
/***********************************GPIO???********************************************/

/***********************************LCD???********************************************/
void LCD_INIT(void){	//???
	GPIO_INIT();	//GPIO????,?LCD_INIT????????
	
	GPIO_Write( GPIOB, 0x0000 << 8 );		//???GPIOB?GOIOB???0x0000,????,????
	GPIO_Write( GPIOB, 0x0000 << 8 );
	
	delay_us(500);
	
	LCD_WRITE_CMD( 0x38 );
	LCD_WRITE_CMD( 0x0d );	//???????
	LCD_WRITE_CMD( 0x06 );
	LCD_WRITE_CMD( 0x01 );
}
/***********************************LCD???********************************************/

/***********************************??????********************************************/
void LCD_WRITE_CMD( unsigned char CMD ){		//??????
	ReadBusy();
	GPIO_ResetBits( GPIOB, LCD1602_Pin_RS );
	GPIO_ResetBits( GPIOB, LCD1602_Pin_RW );
	GPIO_ResetBits( GPIOB, LCD1602_Pin_EN );
	GPIO_Write( GPIOB, CMD << 8 );		//
	GPIO_SetBits( GPIOB, LCD1602_Pin_EN );
	GPIO_ResetBits( GPIOB, LCD1602_Pin_EN );
}
/***********************************??????********************************************/

/***********************************????Byte??********************************************/
void LCD_WRITE_ByteDATA( unsigned char ByteData ){	//????Byte??
	ReadBusy();
	GPIO_SetBits( GPIOB, LCD1602_Pin_RS );
	GPIO_ResetBits( GPIOB, LCD1602_Pin_RW );
	GPIO_ResetBits( GPIOB, LCD1602_Pin_EN );
	GPIO_Write( GPIOB, ByteData << 8 );
	GPIO_SetBits( GPIOB, LCD1602_Pin_EN );
	GPIO_ResetBits( GPIOB, LCD1602_Pin_EN );
}

/***********************************????Byte??********************************************/

/***********************************???????********************************************/

void LCD_WRITE_StrDATA( unsigned char *StrData, unsigned char row, unsigned char col ){//?????
	unsigned char baseAddr = 0x00;			//??8???
	if ( row ){
		baseAddr = 0xc0;
	}else{
		baseAddr = 0x80;																				   
	} 	//row?1???????
		//row?0???????
	baseAddr += col;

	while ( *StrData != '\0' ){

		LCD_WRITE_CMD( baseAddr );
		LCD_WRITE_ByteDATA( *StrData );
	
		baseAddr++;			   //????????,??????
		StrData++;
	}
}
/***********************************???????********************************************/

/***********************************????********************************************/
void ReadBusy(void){		//????,???????????????!!!??STM32?IO?????IO
	GPIO_Write( GPIOB, 0x00ff << 8 );	
	
	GPIO_InitTypeDef p;
	p.GPIO_Pin = GPIO_Pin_15;		//??GPIOB???Pin
	p.GPIO_Mode = GPIO_Mode_IN_FLOATING;	//??Pin????????????,????LCD1602????
	p.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init( GPIOB, &p );
	
	GPIO_ResetBits( GPIOB, LCD1602_Pin_RS );//RS??
	GPIO_SetBits( GPIOB, LCD1602_Pin_RW );//RW??
	
	GPIO_SetBits( GPIOB, LCD1602_Pin_EN );	//???
	while( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_15 ) );	//???Pin??,?????1?????
	GPIO_ResetBits( GPIOB, LCD1602_Pin_EN );//???
		
	p.GPIO_Pin = LCD1602_Pin_IO;		//?GPIOB??????????
	p.GPIO_Mode = GPIO_Mode_Out_PP;
	p.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init( GPIOB, &p  );
}
/***********************************????********************************************/

/***********************************?????????********************************************/
void WUserImg(unsigned char pos,unsigned char *ImgInfo){ //?????????
	unsigned char cgramAddr;			//CGRAM?????????
	
	if( pos <= 1 ) cgramAddr = 0x40;		// 
	if( pos > 1 && pos <= 3 ) cgramAddr = 0x50;
	if( pos > 3 && pos <= 5 ) cgramAddr = 0x60;
	if( pos > 5 && pos <= 7 ) cgramAddr = 0x70;

	LCD_WRITE_CMD( (cgramAddr + (pos%2) * 8) );	//?????????,???0x40??,0x78??
	
	while( *ImgInfo != '\0' ){		//????tem??,????????
		LCD_WRITE_ByteDATA( *ImgInfo );
		ImgInfo++;
	}
}
/***********************************?????????********************************************/

