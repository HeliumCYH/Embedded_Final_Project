#ifndef __Encoder_H
#define __Encoder_H

void Encoder_EXTIInit(void);
int16_t Get_EncoderCountNum(void);

#endif
